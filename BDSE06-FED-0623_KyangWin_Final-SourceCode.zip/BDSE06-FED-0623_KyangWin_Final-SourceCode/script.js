


//***************************************Sign in starts*********************************
// Get the user icon button element
const userIconBtn = document.getElementById('userIconBtn');

// Function to toggle the display of the sign-in modal
function toggleSignInModal() {
  $('#signInModal').modal('toggle');
}

// Add event listener to the user icon button
//userIconBtn.addEventListener('click', toggleSignInModal);

//***************************************Sign in form ends*********************************

  //***************************************RedirectToPage*********************************
 
      function redirectToPage(url) {
          window.location.href = url;
      }
     //***************************************RedirectToPage*********************************
